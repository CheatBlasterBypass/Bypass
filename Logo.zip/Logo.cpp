#include <stdio.h>
#include <conio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>


//AIMSANKE_DWORD.CPP

//LOGO BYPASS

int handle;
typedef char PACKAGENAME;
long int get_module_base(int pid, const char *module_name)
{
	FILE *fp;
	long addr = 0;
	char *pch;
	char filename[32];
	char line[1024];
	snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
	fp = fopen(filename, "r");
	if (fp != NULL)
	{
		while (fgets(line, sizeof(line), fp))
		{
			if (strstr(line, module_name))
			{
				pch = strtok(line, "-");
				addr = strtoul(pch, NULL, 16);
				break;
			}
		}
		fclose(fp);
	}
	return addr;
}

int SANKE_QWORD(long int addr, float value)
{
	pwrite64(handle, &value, 4, addr);
	return 0;
}

int SANKE_DWORD(long int addr, int value)
{
	pwrite64(handle, &value, 4, addr);
	return 0;
}

int getPID(PACKAGENAME * PackageName)
{
	DIR *dir = NULL;
	struct dirent *ptr = NULL;
	FILE *fp = NULL;
	char filepath[256];
	char filetext[128];
	dir = opendir("/proc");
	if (NULL != dir)
	{
		while ((ptr = readdir(dir)) != NULL)
		{

			if ((strcmp(ptr->d_name, ".") == 0) || (strcmp(ptr->d_name, "..") == 0))
				continue;
			if (ptr->d_type != DT_DIR)
				continue;
			sprintf(filepath, "/proc/%s/cmdline", ptr->d_name);
			fp = fopen(filepath, "r");
			if (NULL != fp)
			{
				fgets(filetext, sizeof(filetext), fp);
				if (strcmp(filetext, PackageName) == 0)
				{

					break;
				}
				fclose(fp);
			}
		}
	}
	if (readdir(dir) == NULL)
	{
		return 0;
	}
	closedir(dir);
	return atoi(ptr->d_name);
}

int rebootsystem() {
	return system("su -c 'reboot'");
}


int main(int argc, char **argv)
{
	int gs;
    void *jg;
	FILE *fp;
	char ch, wjm[51];
	
	{
		
	}
	int ipid = getPID("com.pubg.imobile");
	if (ipid == 0)
	{
					puts("Game is not Running \n");
					exit(1);
	}


	char lj[64];
	sprintf(lj, "/proc/%d/mem", ipid);
	handle = open(lj, O_RDWR);
	if (handle == -1)
	{
		 exit(1);
	}
	puts("Join TG : @SANKExOWNER");
	char mname[] = "libUE4.so";
	char nname[] = "libanogs.so";
	char oname[] = "libgcloudcore.so";
	char pname[] = "libgcloud.so";
	char qname[] = "libTdatamaster.so";
	long int UE4 = get_module_base(ipid, mname);
	long int anogs = get_module_base(ipid, nname);
	long int gcloudcore = get_module_base(ipid, oname);
	long int gcloud = get_module_base(ipid, pname);
	long int Tdatamaster = get_module_base(ipid, qname);

//ADD YOUR BYPASS LIKE THIS IN THIS LINEES
SANKE_DWORD_QWORD(anogs + 0x15AF34, 32);
SANKE_DWORD_QWORD(anogs + 0x15AF84, 32);
SANKE_DWORD_QWORD(anogs + 0x15B1EC, 32);
SANKE_DWORD_QWORD(anogs + 0x191128, 32);
SANKE_DWORD_QWORD(anogs + 0x19BAD4, 32);
SANKE_DWORD_QWORD(anogs + 0x19BB44, 32);
SANKE_DWORD_QWORD(anogs + 0x1C0B40, 32);
SANKE_DWORD_QWORD(anogs + 0x1C0B64, 32);
SANKE_DWORD_QWORD(anogs + 0x1C0B98, 32);
SANKE_DWORD_QWORD(anogs + 0x1C0BBC, 32);
SANKE_DWORD_QWORD(anogs + 0x1C0BF0, 32);
SANKE_DWORD_QWORD(anogs + 0x1C0C14, 32);
SANKE_DWORD_QWORD(anogs + 0x1DC5F8, 32);
SANKE_DWORD_QWORD(anogs + 0x1E07D4, 32);
SANKE_DWORD_QWORD(anogs + 0x1E0D24, 32);
SANKE_DWORD_QWORD(anogs + 0x1F6C68, 32);
SANKE_DWORD_QWORD(anogs + 0x1F6D00, 32);
SANKE_DWORD_QWORD(anogs + 0x21EF58, 32);
SANKE_DWORD_QWORD(anogs + 0x21EFC8, 32);
SANKE_DWORD_QWORD(anogs + 0x220EEC, 32);
SANKE_DWORD_QWORD(anogs + 0x220F5C, 32);
SANKE_DWORD_QWORD(anogs + 0x294F78, 32);
SANKE_DWORD_QWORD(anogs + 0x294FE8, 32);
SANKE_DWORD_QWORD(anogs + 0x2A94B0, 32);
SANKE_DWORD_QWORD(anogs + 0x2A951C, 32);
SANKE_DWORD_QWORD(anogs + 0x346F88, 32);
SANKE_DWORD_QWORD(anogs + 0x347948, 32);
SANKE_DWORD_QWORD(anogs + 0x34E2E8, 32);
SANKE_DWORD_QWORD(anogs + 0x34E55C, 32);
SANKE_DWORD_QWORD(anogs + 0x3851C0, 32);//LobbyBypassend

	close(handle);
	return 0;
}